<?php
const RATING = array(
  1 => '⭐',
  2 => '⭐⭐',
  3 => '⭐⭐⭐',
  4 => '⭐⭐⭐⭐',
  5 => '⭐⭐⭐⭐⭐'
);

$show_confirmation = False;

$form_feedback_classes = array(
  'course' => 'hidden',
  'rating' => 'hidden',
  'comments' => 'hidden'
);

$form_values = array(
  'course' => '',
  'rating' => '',
  'comments' => ''
);

$sticky_values = array(
  'course' => '',
  '1' => '',
  '2' => '',
  '3' => '',
  '4' => '',
  '5' => '',
  'comments' => ''
);

// data source: https://infosci.cornell.edu/node/931 //

$db = open_sqlite_db('secure/site.sqlite');

  if (isset($_POST['submit'])) {

    $form_values['course'] = trim($_POST['course']);
    $form_values['rating'] = ($_POST['rating']);
    $form_values['comments'] = trim($_POST['comments']);

    $form_valid = True;


    if ($form_values['course'] == '') {
      $form_valid = False;
      $form_feedback_classes['course'] = '';
    }

    if ($form_values['rating'] == '') {
      $form_valid = False;
      $form_feedback_classes['rating'] = '';
    }

    if ($form_values['comments'] == '') {
      $form_valid = False;
      $form_feedback_classes['comments'] = '';
    }

    if ($form_valid) {

      $result = exec_sql_query(
        $db,
          "INSERT INTO ux (course, ratings, comments)
           VALUES (:course_name, :rating_num, :comments_stuff);",
           array(
            ':course_name' => $form_values['course'],
            ':rating_num' => $form_values['rating'],
            ':comments_stuff' => $form_values['comments']
          )
        );

      $show_confirmation = True;

    } else {
      $sticky_values['course'] = $form_values['course'];
      $sticky_values['1'] = ($form_values['rating'] == '1' ? 'checked' : '');
      $sticky_values['2'] = ($form_values['rating'] == '2' ? 'checked' : '');
      $sticky_values['3'] = ($form_values['rating'] == '3'  ? 'checked' : '');
      $sticky_values['4'] = ($form_values['rating'] == '4' ? 'checked' : '');
      $sticky_values['5'] = ($form_values['rating'] == '5' ? 'checked' : '');
      $sticky_values['comments'] = $form_values['comments'];
    }

  }


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" type="text/css" href="/public/styles/site.css" media="all">
  <title>UX at Cornell University</title>
</head>

<body>
<?php include 'includes/header.php'; ?>

<main >

<?php
$info = exec_sql_query($db, 'SELECT * FROM ux;');
$allinfo = $info->fetchAll();
?>

<table>
<div class="content">
  <tr>
    <th id="course">Course</th>
    <th id="comments">Comments</th>
    <th id="ratings">Ratings</th>
  </tr>

  <?php
  foreach ($allinfo as $eachinfo) { ?>
    <tr>
      <td> <?php echo htmlspecialchars( $eachinfo['course'] ); ?></td>
      <td class="des"><?php echo htmlspecialchars( $eachinfo['comments'] ); ?></td>
      <td><?php echo htmlspecialchars(RATING[ $eachinfo['ratings' ] ] ); ?></td>
    </tr>
  <?php } ?>
</table>

<h1 class="second"> SHARE YOUR EXPERIENCE BY RATING A CLASS! <h1>
<form id="contact" method="POST" action="/" novalidate>
<div class="form">

<?php if (!$show_confirmation) { ?>

    <label class="feedback <?php echo $form_feedback_classes['course']; ?> "> Please enter the name of the class </label>
    <label> Class:
    <br>
    <input type="textarea" name="course" id="course-1"  value="<?php echo $sticky_values['course']; ?>"/> </label>

    <label class="feedback <?php echo $form_feedback_classes['rating']; ?>" > Please rate the class on a scale of 1-5 </label>
    <label class="title"> On a scale of 1-5, how enjoyable was the class? </label>
    <div class="question">
      <label> <input class= "radio" type="radio" name="rating" value="1"  <?php echo $sticky_values['1']; ?>> <p> 1 </p> </label>
      <label> <input class= "radio" type="radio" name="rating" value="2"  <?php echo $sticky_values['2']; ?>> <p> 2  </p> </label>
      <label> <input class= "radio" type="radio" name="rating" value="3"  <?php echo $sticky_values['3']; ?>> <p> 3  </p> </label>
      <label> <input class= "radio" type="radio" name="rating" value="4"  <?php echo $sticky_values['4']; ?>> <p> 4  </p> </label>
      <label> <input class= "radio" type="radio" name="rating" value="5"  <?php echo $sticky_values['5']; ?>> <p> 5  </p> </label>
    </div>

    <label class="feedback <?php echo $form_feedback_classes['comments']; ?>"> Please add your comment on the class </label>
    <label> Comments:
    <input type="textarea" name="comments" id="message"  value="<?php echo $sticky_values['comments']; ?>"/> </label>
    <button label="" id="submit" type="submit" name="submit">Submit</button>

</div>
</div>
</form>

<?php } else {  ?>
  <h2>Thank you for sharing your experience!</h2>
  <p class="link"><a href="/">Submit Another Rating</a></p>
</section>
<?php } ?>

</main>
</body>
</html>
