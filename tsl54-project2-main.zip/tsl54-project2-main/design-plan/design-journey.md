# Project 2: Design Journey

**For each milestone, complete only the sections that are labeled with that milestone.** Refine all sections before the final submission.

You are graded on your design process. If you later need to update your plan, **do not delete the original plan, rather leave it in place and append your new plan _below_ the original.** Then explain why you are changing your plan. Any time you update your plan, you're documenting your design process!

**Replace ALL _TODOs_ with your work.** (There should be no TODOs in the final submission.)

Be clear and concise in your writing. Bullets points are encouraged.

**Everything, including images, must be visible in _Markdown: Open Preview_.** If it's not visible in the Markdown preview, then we can't grade it. We also can't give you partial credit either. **Please make sure your design journey should is easy to read for the grader;** in Markdown preview the question _and_ answer should have a blank line between them.


## Design Plan (Milestone 1)

**Make the case for your decisions using concepts from class, as well as other design principles, theories, examples, and cases from outside of class (includes the design prerequisite for this course).**

You can use bullet points and lists, or full paragraphs, or a combo, whichever is appropriate. The writing should be solid draft quality.


### Catalog (Milestone 1)
> What will your catalog website be about? (1 sentence)

My website will be a course catalog for Information Science majors with UX concentration.

### Audience (Milestone 1)
> Briefly explain your site's audience. Your audience should be specific, but not arbitrarily specific. (1 sentence)
> Justify why this audience is a **cohesive** group. (1-2 sentences)

My site audience is Information Science major undergraduate students who wants to study UX at Cornell University.

My site audience is cohesive because there are many Information Science majors at Cornell univeristy who wants to concentrate in UX and they all need to many coding and design related Information Science classes.

### Audience Goals (Milestone 1)
> Document your audience's goals for using this catalog website.
> List each goal below. There is no specific number of goals required for this, but you need enough to do the job (Hint: It's more than 1. But probably not more than 3.)
> **Hint:** Users will be able to view all entries in the catalog and insert new entries into the catalog. The audience's goals should probably relate to these activities.

Goal 1: To be able to see available classes

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  -I will add a list of classes that students can take and how many credits they can take it for
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - Adding a list of classes with credit count will show the student what options they have and if they will be able to manage the workload for the class.

Goal 2: To have some understanding of the how other students feel about the classes

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - I will add a rating section where students can rate their expereince with the class
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This will inform the student of how other students feel about the courses and make better judgement on whether they want to take the class.

Goal 3: To have some general idea of what the class is about

- **Design Ideas and Choices** _How will you meet those goals in your design?_
  - I will add a section for brief description
- **Rationale & Additional Notes** _Justify your decisions; additional notes._
  - This will inform the student of what the class main goal is and what they expect to gain from taking the class.
  -
### Audience Device (Milestone 1)
> How will your audience access this website? From a narrow (phone) or wide (laptop) device?
> Justify your decision. (1 sentence)

Desktop

Students often look through available courses when they want to plan their schedule, and they usually plan and register their courses using desktops, so they would want to have the list of couses on their desktop.

### Persona (Milestone 1)
> Use the goals you identified above to develop a persona of your site's audience.
> Your persona must have a name and a face. The face can be a photo of a face or a drawing, etc.

 ![nate](nate.jpg)

 [source: https://www.vector4free.com/free-vectors/cartoon-face]

name: Nate

**Factors that Influence Behavior:**

- friends' opinions
- career goals

**Goals:**

- to take relavent and enjoyable classes

**Obstacles:**

- schedule conflicts with other classes

**Desires:**

- to find classes that are relavant and enjoyable

### Catalog Data (Milestone 1)
> Using your persona, identify the data you need to include in the catalog for your site's audience.
> Justify why this data aligns with your persona's goals. (1 sentence)

- InfoSci classes that can be taken to fulfill the UX concentration requirements
- How many credits each class count towards
- Ratings of the classes
- Description of classes

The list of available classes and credits will allow stdents to have access to availabel couses they can take during their time at Cornell to fulfill the requirements for UX concentration and know exactly how many credits each class can count towards their major. The description will give the students general idea about the relavance of the course to their career goals and the ratings from peers to determine if they will find the classes enjoyable.


### Site Design (Milestone 1)
> Design your catalog website to address the goals of your persona.
> Sketch your site's design:
>
> - These are **design** sketches, not _planning_ sketches.
> - Use text in the sketches to help us understand your design.
> - Where the content of the text is unimportant, you may use squiggly lines for text.
> - **Do not label HTML elements or annotate CSS classes.** This is not a planning sketch.
>
> Provide a brief explanation _underneath_ each sketch. (1 sentence)
> **Refer to your persona by name in each explanation.**

 ![design-plan](design-plan.jpg)

This design will help Nate navigate through information about the UX classes at Cornell as he will be able to see all the categories in one page. 

 ![design-plan-2](design-plan-2.jpg)
 
I removed the credit section because I don't think this information give Nate additional information about the classes than the class roster. And for the same reason, I changed the description section to comment section to help Nate get more insight about the class. 

 ![design-plan-3](design-plan-3.jpg)
 
I moved the submit button to the right of the form to guide the users' eyes better so that they can find the submit button easily.

### Catalog Design Patterns (Milestone 1)
> Explain how you used design patterns for online catalogs in your site's design. (1-2 sentences)

I used repetitive design pattern for my online catalog. I made all the texts darker color and the lines lighter color. This is because I do not want Nate to be distracted by bold lines and make it hard for him to locate the relavent text informations.

## Implementation Plan (Milestone 1, Milestone 2)

**Provide enough detail in your plan that another 2300 student could implement your plan.**

### Database Schema (Milestone 1)
> Plan the structure of your database. You may use words or a picture.
> A bulleted list is probably the simplest way to do this.
> Make sure you include constraints for each field.

Table: ux

- key: INT[NN, PK, AI, U]
- course: TEXT[NN]
- comments: TEXT[NN]
- ratings: INT[]

### Database Query Plan (Milestone 1, Final Submission)
> Plan your database queries.
> You may use natural language, pseudocode, or SQL.

1. All Records (Milestone 1)

    ```
    connect to db from router
    open the database
    get query from ux and store all the data in ux-courses
    take individual data and echo it out

    ```

2. Insert Record (Final Submission)

    ```
    if the form is valid, insert the course name, rating number, and the comments into the row in SQLite. 
    Then, return the modified SQLite form.
    
    ```


### From Validation (Milestone 2)
> Plan the validation criteria for each piece of form data.

- Course
  - There needs to be some form of text
- Rating
  - One of the radio need to be selected
- Comments
  - There needs to me some form of text



### Form Planning (Milestone 2)
> Plan your form validation using **pseudocode**.

```
If course textarea is empty, give feedback to user by telling user to enter coursename. 
If one of rating radio choice is  not selected, give user feedback by telling user to select radio.
If comment textarea is empty, give user feedback by telling user to write a comment.

```


### Form Test Data (Milestone 2)
> For each piece of form data, provide samples of valid and invalid data for testing.

**Valid Test Data:**

- course: "INFO 1200", "INFO 1230", "HAI INTERACTION'
- Rating: "1" , "2", "3", "4", "5"
- Comment: "This class was really boring.", "best class ever!"


**Invalid Test Data:**

- course: ""
- Rating: "6", ""
- Comment:""



## Complete & Polished Website (Final Submission)

### Accessibility Audit (Final Submission)
> Tell us what issues you discovered during your accessibility audit.
> What do you do to improve the accessibility of your site?

There were contrast errors for the title of my table, so I changed it the color of the title font to a darker color. 


### Self-Reflection (Final Submission)
> Reflect on what you learned during this assignment. How have you improved from Project 1? What would you do differently next time? (2-3 sentences)

Through this project, I learned how to not only create forms but also give users effective feedbacks to make sure the form has all the neccessary inputs from the users. I also learned how to create forms to dynamically change datasets and allow users to seee immediate results of their actions. In future assignments, I would probably create a list of all the courses and allow users to choose the classes in a form of dropbox and rate that class. 

> Take some time here to reflect on how much you've learned since you started this class. It's often easy to ignore our own progress. Take a moment and think about your accomplishments in this class. Hopefully you'll recognize that you've accomplished a lot and that you should be very proud of those accomplishments! (1-3 sentences)

When I started this class, I knew nothing of PHP or SQLite. However, after this assignment, I feel that I am able to work with any PHP and SQLite files because I understand now how to understand PHP codes and practiced a lot with SQLite. 

### Collaborators (Final Submission)
> List any persons you collaborated with on this project.

I did not collaborate with anyone on this project. 

### Reference Resources (Final Submission)
> Please cite any external resources you referenced in the creation of your project.
> (i.e. W3Schools, StackOverflow, Mozilla, etc.)

https://infosci.cornell.edu/undergraduate/info-sci-majors/bs-information-science-cals/degree-requirements/concentrations/ux-user
