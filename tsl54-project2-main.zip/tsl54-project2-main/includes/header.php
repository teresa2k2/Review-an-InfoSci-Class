<header>
<link rel="stylesheet" type="text/css" href="/public/styles/site.css" media="all">
<h1> Cornell University </h1>
<h2> User Experience </h2>
</header>
